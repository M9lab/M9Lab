/*
 * LegoinoCommon.cpp - Arduino Library for converting values with different types
 *
 * (c) Copyright 2020 - Cornelius Munz
 * Released under MIT License
 *
*/

#if defined(ESP32)

#include "LegoinoCommon.h"

/**
 * @brief Map speed from -100..100 to the 8bit internal value
 * @param [in] speed -100..100
 */
byte LegoinoCommon::MapSpeed(int speed)
{
    byte rawSpeed;
    if (speed == 0)
    {
        rawSpeed = 127; // stop motor
    }
    else if (speed > 0)
    {
        rawSpeed = map(speed, 0, 100, 0, 126);
    }
    else
    {
        rawSpeed = map(-speed, 0, 100, 255, 128);
    }
    return rawSpeed;
}

/**
 * @brief return string value of color enum
 * @param [in] Color enum
 */
std::string LegoinoCommon::ColorStringFromColor(Color color)
{
    return ColorStringFromColor((int)color);
}

/**
 * @brief return string value of color enum
 * @param [in] Color int value
 */
std::string LegoinoCommon::ColorStringFromColor(int color)
{
    if (color > Color::NUM_COLORS) {
        return std::string(COLOR_STRING[Color::NUM_COLORS]);
    } 
    else 
    {
        return std::string(COLOR_STRING[color]);
    }
}

byte *LegoinoCommon::Int16ToByteArray(int16_t x)
{
    static byte y[2];
    y[0] = (byte)(x & 0xff);
    y[1] = (byte)((x >> 8) & 0xff);
    return y;
}

byte *LegoinoCommon::Int32ToByteArray(int32_t x)
{
    static byte y[4];
    y[0] = (byte)(x & 0xff);
    y[1] = (byte)((x >> 8) & 0xff);
    y[2] = (byte)((x >> 16) & 0xff);
    y[3] = (byte)((x >> 24) & 0xff);
    return y;
}

unsigned char LegoinoCommon::ReadUInt8(uint8_t *data, int offset)
{
    unsigned char value = data[0 + offset];
    return value;
}

signed char LegoinoCommon::ReadInt8(uint8_t *data, int offset)
{
    signed char value = (signed char)data[0 + offset];
    return value;
}

unsigned short LegoinoCommon::ReadUInt16LE(uint8_t *data, int offset)
{
    unsigned short value = data[0 + offset] | (unsigned short)(data[1 + offset] << 8);
    return value;
}

signed short LegoinoCommon::ReadInt16LE(uint8_t *data, int offset)
{
    signed short value = data[0 + offset] | (signed short)(data[1 + offset] << 8);
    return value;
}

unsigned int LegoinoCommon::ReadUInt32LE(uint8_t *data, int offset)
{
    unsigned int value = data[0 + offset] | (unsigned int)(data[1 + offset] << 8) | (unsigned int)(data[2 + offset] << 16) | (unsigned int)(data[3 + offset] << 24);
    return value;
}

signed int LegoinoCommon::ReadInt32LE(uint8_t *data, int offset)
{
    signed int value = data[0 + offset] | (int16_t)(data[1 + offset] << 8) | (unsigned int)(data[2 + offset] << 16) | (unsigned int)(data[3 + offset] << 24);
    return value;
}

#endif // ESP32